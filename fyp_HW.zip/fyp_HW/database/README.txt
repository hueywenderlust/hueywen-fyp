==========================================================
                       DB credential
==========================================================

database name: 'sample';
host: 'localhost';
username: 'root';
password: '';

===========================================================
                   Admin Login Credential
===========================================================

username: admin
password: admin

--------------------

username: pizza
password: pizza

--------------------

# password default to be same as username (for admins)
# password default to be same as staff ID (for users)


=============================================================
                       User Login Credential
=============================================================

email: ryan@example.com
password: 100001

---------------------------

email: john@example.com
password: 100022

